import sys
import re

with open('C:/Users/Asus/.gemini/antigravity/scratch/sidebar-plugin-integration/script.js', 'r', encoding='utf-8') as f:
    text = f.read()

# Add state and function
header = '''window.trailBreaks = { break1: 'pending', lunch: 'pending', evening: 'pending' };

function updateTrailProgress(w) {
    const fill = document.getElementById('trail-progress-fill');
    if (!fill) return;

    fill.style.width = (w === 17 || w === 56 || w === 88) ? 'calc(' + w + '% + 4px)' : w + '%';
    
    // Initial color
    if (w <= 10) { fill.style.background = '#6B66C7'; fill.style.boxShadow = 'none'; return; }
    
    let bg = 'linear-gradient(90deg, #6B66C7 0%';

    if (w >= 16) {
        let p = (17 / w) * 100;
        let c = window.trailBreaks.break1 === 'skipped' ? '#3B3673' : '#FCD135';
        bg += ', #6B66C7 ' + (p - 8) + '%, ' + c + ' ' + p + '%';
        if (w > 18) bg += ', #6B66C7 ' + (p + 8) + '%';
    }
    if (w >= 54) {
        let p = (56 / w) * 100;
        let c = window.trailBreaks.lunch === 'skipped' ? '#3B3673' : '#FCD135';
        bg += ', #6B66C7 ' + (p - 8) + '%, ' + c + ' ' + p + '%';
        if (w > 57) bg += ', #6B66C7 ' + (p + 8) + '%';
    }
    if (w >= 87) {
        let p = (88 / w) * 100;
        let c = window.trailBreaks.evening === 'skipped' ? '#3B3673' : '#FCD135';
        bg += ', #6B66C7 ' + (p - 5) + '%, ' + c + ' ' + p + '%';
        if (w > 89) bg += ', #6B66C7 ' + (p + 5) + '%';
    }
    
    bg += ', #6B66C7 100%)';
    fill.style.background = bg;
    fill.style.boxShadow = 'none';
}

document.addEventListener('DOMContentLoaded', () => {'''

text = text.replace("document.addEventListener('DOMContentLoaded', () => {", header)

replacements = [
    (r"progressFill\.style\.width = '10%';[\s\S]*?progressFill\.style\.boxShadow = 'none';", "updateTrailProgress(10);"),
    (r"progressFill\.style\.width = '17%';[\s\S]*?progressFill\.style\.boxShadow = 'none';", "updateTrailProgress(17);"),
    (r"progressFill\.style\.width = '35%';[\s\S]*?progressFill\.style\.boxShadow = 'none';", "updateTrailProgress(35);"),
    (r"progressFill\.style\.width = '56%';[\s\S]*?progressFill\.style\.boxShadow = 'none';", "updateTrailProgress(56);"),
    (r"progressFill\.style\.width = '75%';[\s\S]*?progressFill\.style\.boxShadow = 'none';", "updateTrailProgress(75);"),
    (r"progressFill\.style\.width = '88%';[\s\S]*?progressFill\.style\.boxShadow = 'none';", "updateTrailProgress(88);"),
    (r"progressFill\.style\.width = '100%';[\s\S]*?progressFill\.style\.boxShadow = 'none';", "updateTrailProgress(100);"),
]

for pat, repl in replacements:
    text = re.sub(pat, repl, text)

# Replace btnIn handlers explicitly using string replace on smaller distinct parts
text = text.replace('''                            progressFill.style.width = '62%'; 
                            progressFill.style.background = 'linear-gradient(90deg, #6B66C7 0%, #6B66C7 19%, #FCD135 27%, #6B66C7 35%, #6B66C7 82%, #FCD135 90%, #6B66C7 98%, #6B66C7 100%)';
                            progressFill.style.boxShadow = 'none';''', "window.trailBreaks.lunch = 'taken'; updateTrailProgress(62);")

text = text.replace('''                            progressFill.style.width = '93%'; 
                            progressFill.style.background = 'linear-gradient(90deg, #6B66C7 0%, #6B66C7 16%, #FCD135 18%, #6B66C7 20%, #6B66C7 58%, #FCD135 60%, #6B66C7 62%, #6B66C7 93%, #FCD135 95%, #6B66C7 97%, #6B66C7 100%)';
                            progressFill.style.boxShadow = 'none';''', "window.trailBreaks.evening = 'taken'; updateTrailProgress(93);")

text = text.replace('''                            // Advance the progress bar past the first dot
                            progressFill.style.width = '23%'; 
                            progressFill.style.background = 'linear-gradient(90deg, #6B66C7 0%, #6B66C7 60%, #FCD135 74%, #6B66C7 88%, #6B66C7 100%)';
                            progressFill.style.boxShadow = 'none';''', "// Advance the progress bar past the first dot\n                            window.trailBreaks.break1 = 'taken'; updateTrailProgress(23);")


btn_maybe_logic = '''
                            // Revert colors for the next time the modal opens
                            btnMaybe.style.background = 'transparent';
                            btnMaybe.style.color = '#A4A1DF';
                            btnMaybe.style.borderColor = '#625DA3';

                            if (window.trailModalContext === 'lunch') {
                                window.trailBreaks.lunch = 'skipped';
                                const b = document.getElementById('task-break-lunch');
                                if (b) { b.style.backgroundColor = '#292929'; b.style.borderColor = '#4A4852'; b.style.color = '#737373'; const s = b.querySelector('svg'); if(s) s.style.stroke = '#737373'; }
                                const d = document.getElementById('dot-2');
                                if (d) { d.style.background = '#8A856A'; d.style.transform = 'scale(0.7)'; }
                                updateTrailProgress(62);
                            } else if (window.trailModalContext === 'evening') {
                                window.trailBreaks.evening = 'skipped';
                                const b = document.getElementById('task-break-3');
                                if (b) { b.style.backgroundColor = '#292929'; b.style.borderColor = '#4A4852'; const s = b.querySelector('svg'); if(s) s.style.stroke = '#737373'; }
                                const d = document.getElementById('dot-3');
                                if (d) { d.style.background = '#8A856A'; d.style.transform = 'scale(0.7)'; }
                                updateTrailProgress(93);
                            } else {
                                window.trailBreaks.break1 = 'skipped';
                                const b = document.getElementById('task-break-1');
                                if (b) { b.style.backgroundColor = '#292929'; b.style.borderColor = '#4A4852'; const s = b.querySelector('svg'); if(s) s.style.stroke = '#737373'; }
                                const d = document.getElementById('dot-1');
                                if (d) { d.style.background = '#8A856A'; d.style.transform = 'scale(0.7)'; }
                                updateTrailProgress(23);
                            }'''

text = text.replace('''
                            // Revert colors for the next time the modal opens
                            btnMaybe.style.background = 'transparent';
                            btnMaybe.style.color = '#A4A1DF';
                            btnMaybe.style.borderColor = '#625DA3';''', btn_maybe_logic)

with open('C:/Users/Asus/.gemini/antigravity/scratch/sidebar-plugin-integration/script.js', 'w', encoding='utf-8') as f:
    f.write(text)
