document.addEventListener('DOMContentLoaded', () => {
    const moreOptionsBtn = document.getElementById('more-options-btn');
    const moreOptionsPanel = document.getElementById('more-options-panel');
    const addPluginBtn = document.getElementById('add-plugin-btn');
    const dynamicInsertionPoint = document.getElementById('dynamic-insertion-point');
    const statusIcon = addPluginBtn.querySelector('.status-icon');

    window.trailBreaks = { break1: 'pending', lunch: 'pending', evening: 'pending' };

    window.updateTrailProgress = function(w) {
        const fill = document.getElementById('trail-progress-fill');
        if (!fill) return;

        fill.style.width = (w === 17 || w === 56 || w === 88) ? `calc(${w}% + 4px)` : `${w}%`;
        if (w <= 10) { fill.style.background = '#6B66C7'; fill.style.boxShadow = 'none'; return; }
        
        let bg = 'linear-gradient(90deg, #6B66C7 0%';

        if (w >= 16) {
            let p = (17 / w) * 100;
            let c = window.trailBreaks.break1 === 'skipped' ? '#3B3673' : '#FCD135';
            bg += `, #6B66C7 ${p - 8}%, ${c} ${p}%`;
            if (w > 18) bg += `, #6B66C7 ${p + 8}%`;
        }
        if (w >= 54) {
            let p = (56 / w) * 100;
            let c = window.trailBreaks.lunch === 'skipped' ? '#3B3673' : '#FCD135';
            bg += `, #6B66C7 ${p - 8}%, ${c} ${p}%`;
            if (w > 57) bg += `, #6B66C7 ${p + 8}%`;
        }
        if (w >= 87) {
            let p = (88 / w) * 100;
            let c = window.trailBreaks.evening === 'skipped' ? '#3B3673' : '#FCD135';
            bg += `, #6B66C7 ${p - 5}%, ${c} ${p}%`;
            if (w > 89) bg += `, #6B66C7 ${p + 5}%`;
        }
        
        bg += `, #6B66C7 100%)`;
        fill.style.background = bg;
        fill.style.boxShadow = 'none';
    };

    // Toggle Panel
    moreOptionsBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        
        // Match the panel top position nicely next to the trigger
        const btnRect = moreOptionsBtn.getBoundingClientRect();
        moreOptionsPanel.style.top = `${btnRect.top}px`;
        
        moreOptionsPanel.classList.toggle('visible');
    });

    // Close panel when clicking outside
    document.addEventListener('click', (e) => {
        if (!moreOptionsPanel.contains(e.target) && !moreOptionsBtn.contains(e.target)) {
            moreOptionsPanel.classList.remove('visible');
        }
    });

    // Prevent closing when clicking inside panel
    moreOptionsPanel.addEventListener('click', (e) => {
        e.stopPropagation();
    });

    // Handle Adding Plugin
    addPluginBtn.addEventListener('click', () => {
        // Prevent multiple clicks while animating
        if (addPluginBtn.classList.contains('selected')) return;

        // Visual feedback inside panel: Show success style and checkmark
        addPluginBtn.classList.add('selected');
        statusIcon.classList.add('active');

        // Wait to show the checkmark, then process the sidebar insertion
        setTimeout(() => {
            // 1. Hide Panel
            moreOptionsPanel.classList.remove('visible');

            // 2. Wait for panel to close before adding to sidebar to make it sequential
            setTimeout(() => {
                // Reset panel item state (so it looks normal if opened again)
                addPluginBtn.classList.remove('selected');
                statusIcon.classList.remove('active');

                // 3. Add the new item to sidebar with animation
                const newNavItem = document.createElement('a');
                newNavItem.href = '#';
                newNavItem.className = 'nav-item added-item';
                
                // SVG matching the Trail icon
                newNavItem.innerHTML = `
                    <svg viewBox="0 0 100 100" width="22" height="22" style="background:#0a0a0a; border-radius:4px; margin-bottom: 2px;">
                        <rect x="10" y="15" width="80" height="15" fill="#F4C744"/>
                        <rect x="25" y="30" width="15" height="55" fill="#F4C744"/>
                        <text x="35" y="75" font-family="cursive, 'Segoe UI', Arial, sans-serif" font-style="italic" font-size="45" fill="#F4C744">rail</text>
                    </svg>
                    <span style="font-size: 11px; margin-bottom: 3px;">Trail</span>
                    <div style="width: 6px; height: 6px; background-color: #39FF14; border-radius: 50%; box-shadow: 0 0 4px rgba(57, 255, 20, 0.5);"></div>
                `;

                // Insert into the wrapper div above the "more options" button
                dynamicInsertionPoint.appendChild(newNavItem);
                
                // Show dynamic content
                const schedule = document.getElementById('trail-schedule');
                if(schedule) schedule.style.display = 'block';
                const headerInfo = document.getElementById('trail-header-info');
                if(headerInfo) headerInfo.style.display = 'flex';
                
                // Keep track of which break we are targeting
                window.trailModalContext = 'break1';
                
                // Set up click interactivity for the first task
                const task1 = document.getElementById('task-1');
                const progressFill = document.getElementById('trail-progress-fill');
                if (task1 && progressFill) {
                    task1.addEventListener('click', () => {
                        // Turn block purple
                        task1.style.backgroundColor = '#4A467F'; // Exact shade from image
                        task1.style.borderColor = '#5A569A';
                        
                        // Advance the progress bar
                        window.updateTrailProgress(10);
                    });
                }
                
                const task2 = document.getElementById('task-2');
                if (task2 && progressFill) {
                    task2.addEventListener('click', () => {
                        // Turn task 2 purple
                        task2.style.backgroundColor = '#4A467F'; 
                        task2.style.borderColor = '#5A569A';
                        
                        // Automatically complete task 1 if not done already for progression effect
                        if(task1) {
                            task1.style.backgroundColor = '#4A467F';
                            task1.style.borderColor = '#5A569A';
                        }
                        
                        // Advance bar exactly to the first dot
                        window.updateTrailProgress(17);
                        
                        // Show popup slightly after progression finishes
                        setTimeout(() => {
                            const modal = document.getElementById('trail-modal-overlay');
                            if(modal) {
                                modal.style.display = 'flex';
                                modal.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 300, fill: 'forwards' });
                            }
                        }, 600);
                    });
                }
                
                const task3 = document.getElementById('task-3');
                if (task3 && progressFill) {
                    task3.addEventListener('click', () => {
                        task3.style.backgroundColor = '#4A467F'; 
                        task3.style.borderColor = '#5A569A';
                        if(document.getElementById('task-1')) { document.getElementById('task-1').style.backgroundColor = '#4A467F'; document.getElementById('task-1').style.borderColor = '#5A569A'; }
                        if(task2) { task2.style.backgroundColor = '#4A467F'; task2.style.borderColor = '#5A569A'; }
                        
                        // Break 1 ensures it's completed
                        const break1 = document.getElementById('task-break-1');
                        if (break1 && window.trailBreaks.break1 !== 'skipped') {
                            break1.style.backgroundColor = '#FCD135';
                            break1.style.borderColor = '#FCD135';
                            const svg = break1.querySelector('svg');
                            if(svg) svg.style.stroke = '#111';
                        }
                        
                        window.updateTrailProgress(35);
                        if (window.trailBreaks.break1 === 'skipped') {
                            setTimeout(() => {
                                const missedModal = document.getElementById('trail-missed-modal-overlay');
                                if(missedModal) {
                                    missedModal.style.display = 'flex';
                                    missedModal.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 300, fill: 'forwards' });
                                }
                            }, 400);
                        }
                    });
                }
                
                const task4 = document.getElementById('task-4');
                if (task4 && progressFill) {
                    task4.addEventListener('click', () => {
                        task4.style.backgroundColor = '#4A467F'; 
                        task4.style.borderColor = '#5A569A';
                        if(task3) { task3.style.backgroundColor = '#4A467F'; task3.style.borderColor = '#5A569A'; }
                        
                        window.updateTrailProgress(56);
                        
                        window.trailModalContext = 'lunch';
                        
                        setTimeout(() => {
                            const badge = document.getElementById('modal-badge-text');
                            const title = document.getElementById('modal-title');
                            const duration = document.getElementById('modal-duration');
                            const desc = document.getElementById('modal-desc');
                            
                            if (badge) badge.innerText = "Someone Started a Lunch Trail...";
                            if (title) title.innerText = "Care to join them??";
                            if (duration) duration.innerText = "60-minute";
                            if (desc) desc.innerHTML = 'Grab a bite and head to the cafeteria to <span class="pulse-yellow-text" style="font-weight: 600;">join the trail.</span>';
                            
                            const modal = document.getElementById('trail-modal-overlay');
                            if(modal) {
                                modal.style.display = 'flex';
                                modal.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 300, fill: 'forwards' });
                            }
                        }, 600);
                    });
                }
                
                const task5 = document.getElementById('task-5');
                if (task5 && progressFill) {
                    task5.addEventListener('click', () => {
                        task5.style.backgroundColor = '#4A467F'; task5.style.borderColor = '#5A569A';
                        if(task4) { task4.style.backgroundColor = '#4A467F'; task4.style.borderColor = '#5A569A'; }
                        
                        const lunchBreak = document.getElementById('task-break-lunch');
                        if (lunchBreak && window.trailBreaks.lunch !== 'skipped') {
                            lunchBreak.style.backgroundColor = '#FCD135'; lunchBreak.style.borderColor = '#FCD135'; lunchBreak.style.color = '#111';
                            const svg = lunchBreak.querySelector('svg'); if(svg) svg.style.stroke = '#111';
                        }
                        
                        window.updateTrailProgress(75);
                        if (window.trailBreaks.lunch === 'skipped') {
                            setTimeout(() => {
                                const missedModal = document.getElementById('trail-missed-modal-overlay');
                                if(missedModal) {
                                    missedModal.style.display = 'flex';
                                    missedModal.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 300, fill: 'forwards' });
                                }
                            }, 400);
                        }
                    });
                }

                const task6 = document.getElementById('task-6');
                if (task6 && progressFill) {
                    task6.addEventListener('click', () => {
                        task6.style.backgroundColor = '#4A467F'; task6.style.borderColor = '#5A569A';
                        if(task5) { task5.style.backgroundColor = '#4A467F'; task5.style.borderColor = '#5A569A'; }
                        
                        window.updateTrailProgress(88);
                        
                        window.trailModalContext = 'evening';
                        
                        setTimeout(() => {
                            const badge = document.getElementById('modal-badge-text');
                            const title = document.getElementById('modal-title');
                            const duration = document.getElementById('modal-duration');
                            const desc = document.getElementById('modal-desc');
                            
                            if (badge) badge.innerText = "Someone Started an Evening Trail...";
                            if (title) title.innerText = "Close out the day together??";
                            if (duration) duration.innerText = "15-minute";
                            if (desc) desc.innerHTML = 'Head to the recreation area to <span class="pulse-yellow-text" style="font-weight: 600;">join the trail.</span>';
                            
                            const modal = document.getElementById('trail-modal-overlay');
                            if(modal) {
                                modal.style.display = 'flex';
                                modal.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 300, fill: 'forwards' });
                            }
                        }, 600);
                    });
                }
                
                const task7 = document.getElementById('task-7');
                if (task7 && progressFill) {
                    task7.addEventListener('click', () => {
                        task7.style.backgroundColor = '#4A467F'; task7.style.borderColor = '#5A569A';
                        if(task6) { task6.style.backgroundColor = '#4A467F'; task6.style.borderColor = '#5A569A'; }
                        
                        const break3 = document.getElementById('task-break-3');
                        if (break3 && window.trailBreaks.evening !== 'skipped') {
                            break3.style.backgroundColor = '#FCD135'; break3.style.borderColor = '#FCD135';
                            const svg = break3.querySelector('svg'); if(svg) svg.style.stroke = '#111';
                        }
                        
                        window.updateTrailProgress(100);

                        setTimeout(() => {
                            let takenCount = 0;
                            if(window.trailBreaks.break1 === 'taken') takenCount++;
                            if(window.trailBreaks.lunch === 'taken') takenCount++;
                            if(window.trailBreaks.evening === 'taken') takenCount++;

                            if (takenCount === 0) {
                                const failureModal = document.getElementById('trail-failure-modal-overlay');
                                if (failureModal) {
                                    failureModal.style.display = 'flex';
                                    failureModal.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 600, fill: 'forwards' });
                                }
                                return;
                            }

                            const successModal = document.getElementById('trail-success-modal-overlay');
                            if(successModal) {
                                const titleEl = document.getElementById('success-modal-title');
                                const subEl = document.getElementById('success-modal-subtitle');
                                if (titleEl && subEl) {
                                    if (takenCount === 3) {
                                        titleEl.innerHTML = "You took all three<br>breaks today.";
                                        subEl.innerText = "Nice work staying in flow.";
                                    } else if (takenCount === 2) {
                                        titleEl.innerHTML = "You took two<br>breaks today.";
                                        subEl.innerText = "Great job protecting your focus.";
                                    } else if (takenCount === 1) {
                                        titleEl.innerHTML = "You took one<br>break today.";
                                        subEl.innerText = "Take more time to recharge.";
                                    }
                                }

                                successModal.style.display = 'flex';
                                successModal.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 600, fill: 'forwards' });
                            }
                        }, 800);
                    });
                }
                
                // Success Modal Close Handler
                const successClose = document.getElementById('trail-success-close');
                if (successClose) {
                    successClose.addEventListener('click', () => {
                        const successModal = document.getElementById('trail-success-modal-overlay');
                        if (successModal) successModal.style.display = 'none';
                    });
                }
                
                // Modal specific button handlers
                const btnIn = document.getElementById('trail-in-btn');
                const btnMaybe = document.getElementById('trail-maybe-btn');
                const trailOverlay = document.getElementById('trail-modal-overlay');

                if (btnIn && trailOverlay) {
                    btnIn.addEventListener('click', () => {
                        trailOverlay.style.display = 'none';
                        
                        if (window.trailModalContext === 'lunch') {
                            const lunchBreak = document.getElementById('task-break-lunch');
                            if (lunchBreak) {
                                lunchBreak.style.backgroundColor = '#FCD135';
                                lunchBreak.style.borderColor = '#FCD135';
                                lunchBreak.style.color = '#111'; // dark text against yellow
                                lunchBreak.style.boxShadow = '0 0 10px rgba(252, 209, 53, 0.4)';
                                const svg = lunchBreak.querySelector('svg');
                                if(svg) svg.style.stroke = '#111';
                            }
                            window.trailBreaks.lunch = 'taken';
                            window.updateTrailProgress(62);
                        } else if (window.trailModalContext === 'evening') {
                            const break3 = document.getElementById('task-break-3');
                            if (break3) {
                                break3.style.backgroundColor = '#FCD135'; break3.style.borderColor = '#FCD135';
                                const svg = break3.querySelector('svg'); if(svg) svg.style.stroke = '#111';
                            }
                            window.trailBreaks.evening = 'taken';
                            window.updateTrailProgress(93);
                        } else {
                            // Turn the break block yellow
                            const break1 = document.getElementById('task-break-1');
                            if (break1) {
                                break1.style.backgroundColor = '#FCD135';
                                break1.style.borderColor = '#FCD135';
                                break1.style.boxShadow = '0 0 10px rgba(252, 209, 53, 0.4)';
                                const svg = break1.querySelector('svg');
                                if(svg) svg.style.stroke = '#111';
                            }
                            
                            window.trailBreaks.break1 = 'taken';
                            window.updateTrailProgress(23);
                        }
                    });
                }
                if (btnMaybe && trailOverlay) {
                    btnMaybe.addEventListener('click', () => {
                        // Turn solid purple when clicked
                        btnMaybe.style.background = '#8B87C1';
                        btnMaybe.style.color = '#2B2B6A';
                        btnMaybe.style.borderColor = '#8B87C1';
                        
                        // Wait a short moment to show the color, then close
                        setTimeout(() => {
                            trailOverlay.style.display = 'none';
                            
                            // Revert colors for the next time the modal opens
                            btnMaybe.style.background = 'transparent';
                            btnMaybe.style.color = '#A4A1DF';
                            btnMaybe.style.borderColor = '#625DA3';

                            if (window.trailModalContext === 'lunch') {
                                window.trailBreaks.lunch = 'skipped';
                                const b = document.getElementById('task-break-lunch');
                                if (b) { b.style.backgroundColor = '#353535'; b.style.borderColor = '#4A4852'; b.style.color = '#737373'; const s = b.querySelector('svg'); if(s) s.style.stroke = '#737373'; }
                                const d = document.getElementById('dot-2');
                                if (d) { d.style.background = '#8A856A'; d.style.transform = 'scale(0.7)'; d.style.top = '-13px'; }
                                window.updateTrailProgress(62);
                            } else if (window.trailModalContext === 'evening') {
                                window.trailBreaks.evening = 'skipped';
                                const b = document.getElementById('task-break-3');
                                if (b) { b.style.backgroundColor = '#353535'; b.style.borderColor = '#4A4852'; const s = b.querySelector('svg'); if(s) s.style.stroke = '#737373'; }
                                const d = document.getElementById('dot-3');
                                if (d) { d.style.background = '#8A856A'; d.style.transform = 'scale(0.7)'; d.style.top = '-13px'; }
                                window.updateTrailProgress(93);
                            } else {
                                window.trailBreaks.break1 = 'skipped';
                                const b = document.getElementById('task-break-1');
                                if (b) { b.style.backgroundColor = '#353535'; b.style.borderColor = '#5B5B5B'; const s = b.querySelector('svg'); if(s) s.style.stroke = '#777'; }
                                const d = document.getElementById('dot-1');
                                if (d) { d.style.background = '#82806D'; d.style.transform = 'scale(0.8)'; d.style.top = '-13px'; }
                                window.updateTrailProgress(23);
                            }
                        }, 250);
                    });
                }

            }, 250); // delay matching panel hide transition

        }, 800); // 800ms delay to enjoy the checkmark
    });

    // Global Success Modal Close Handlers
    const successCloseGlobal = document.getElementById('trail-success-close');
    const successModalGlobal = document.getElementById('trail-success-modal-overlay');
    const missedModalGlobal = document.getElementById('trail-missed-modal-overlay');
    const remindBtnGlobal = document.getElementById('trail-remind-btn');
    const failureModalGlobal = document.getElementById('trail-failure-modal-overlay');
    const failureRemindBtnGlobal = document.getElementById('trail-failure-remind-btn');
    
    if (remindBtnGlobal) {
        remindBtnGlobal.addEventListener('click', () => {
            if(missedModalGlobal) missedModalGlobal.style.display = 'none';
        });
    }

    if (failureRemindBtnGlobal) {
        failureRemindBtnGlobal.addEventListener('click', () => {
            if(failureModalGlobal) failureModalGlobal.style.display = 'none';
        });
    }
    
    if (successCloseGlobal) {
        successCloseGlobal.addEventListener('click', () => {
            if (successModalGlobal) successModalGlobal.style.display = 'none';
        });
    }
    
    if (successModalGlobal) {
        successModalGlobal.addEventListener('click', (e) => {
            if (e.target === successModalGlobal) successModalGlobal.style.display = 'none';
        });
    }
});
